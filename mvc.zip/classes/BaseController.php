<?php

abstract class BaseController
{
    public function __construct(){

    }
    abstract public function index();
}