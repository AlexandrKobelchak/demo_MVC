<?php


class HomeController extends BaseController
{

    public function index()
    {
        return  new View();
        //echo "<html><head><title>TEST</title></head><body><h1>TEST</h1></body></html>";


    }
}