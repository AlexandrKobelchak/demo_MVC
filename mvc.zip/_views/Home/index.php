<?php ?>

<html>
<head>
    <title>index</title>
</head>
<body>
<h1>Index</h1>
</body>
</html>
