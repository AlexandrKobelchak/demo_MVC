<?php

class Config{

    const hostName = "http://www.mvc.local";

    const databaseServer = "localhost";
    const databaseName = "";
    const databaseUser = "";
    const databasePasswd = "";
}
